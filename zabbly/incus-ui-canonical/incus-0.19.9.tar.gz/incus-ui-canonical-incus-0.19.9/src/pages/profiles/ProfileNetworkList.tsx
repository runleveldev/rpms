import type { FC } from "react";
import type { LxdProfile } from "types/profile";
import { isNicDevice } from "util/devices";
import ExpandableList from "components/ExpandableList";
import ResourceLink from "components/ResourceLink";

interface Props {
  profile: LxdProfile;
  project: string;
}

const ProfileNetworkList: FC<Props> = ({ profile, project }) => {
  return (
    <>
      {Object.values(profile.devices).some(isNicDevice) ? (
        <ExpandableList
          items={Object.values(profile.devices)
            .filter(isNicDevice)
            .map((device) => (
              <ResourceLink
                key={device.network}
                type="network"
                value={device.network}
                to={`/ui/project/${encodeURIComponent(project)}/network/${encodeURIComponent(device.network)}`}
              />
            ))}
        />
      ) : (
        <div className="list-item">-</div>
      )}
    </>
  );
};

export default ProfileNetworkList;
